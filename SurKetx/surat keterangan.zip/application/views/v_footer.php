   </div><!-- /.content-wrapper -->


</div><!-- ./wrapper -->


<!-- Bootstrap 3.3.2 JS -->
<script src="<?php echo base_url('assets/AdminLTE-2.3.11/bootstrap/js/bootstrap.min.js'); ?>" type="text/javascript"></script>
<!-- DataTables -->
<script src="<?php echo base_url('assets/AdminLTE-2.3.11/plugins/datatables/jquery.dataTables.min.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/AdminLTE-2.3.11/plugins/datatables/dataTables.bootstrap.min.js"'); ?>" type="text/javascript"></script>
<!-- CK Editor -->
<script src="<?php echo base_url('assets/AdminLTE-2.3.11/plugins/ckeditor/ckeditor.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/AdminLTE-2.3.11/plugins/ckeditor/config.js'); ?>" type="text/javascript"></script>
<!-- SlimScroll -->
<script src="<?php echo base_url('assets/AdminLTE-2.3.11/plugins/slimScroll/jquery.slimscroll.min.js'); ?>" type="text/javascript"></script>
<!-- FastClick -->
<script src='<?php echo base_url('assets/AdminLTE-2.3.11/plugins/fastclick/fastclick.min.js'); ?>'></script>
<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBaxYs3Ln76Tl6kvdu4u44AuDd_VjqhFfA"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('assets/AdminLTE-2.3.11/dist/js/app.min.js'); ?>" type="text/javascript"></script>
<!-- Compress Image -->
<script type="text/javascript" src="<?php echo base_url('assets/admin/js/compressImage.js'); ?>"></script>
<!--  Ajax -->
<!-- <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.0/Chart.bundle.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.0/Chart.min.js"></script> -->
<!-- FLOT CATEGORIES PLUGIN - Used to draw bar charts -->
<script src="<?php echo base_url('assets/AdminLTE-2.3.11/plugins/flot/jquery.flot.pie.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/AdminLTE-2.3.11/plugins/flot/jquery.flot.categories.min.js'); ?>"></script>



<!--  Ajax -->
<script src="<?php echo base_url('assets/admin/js/ajax.js') ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/admin/js/ajax2.js') ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/AdminLTE-2.3.11/plugins/select2/select2.full.min.js'); ?>"></script>


   </body>
</html>

