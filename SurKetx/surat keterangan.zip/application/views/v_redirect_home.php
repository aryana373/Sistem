<script type="text/javascript">
   //window.location=<?php base_url('Login'); ?>;
   window.location='https://slims.invite-me.my.id/admin';
</script>