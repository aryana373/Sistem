<?php
class Pdf {
 
    function __construct() {
        include_once APPPATH . '/third_party/TCPDF/tcpdf.php'; 
    }
}